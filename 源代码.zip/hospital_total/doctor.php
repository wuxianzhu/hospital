<?php

session_start();
if (isset($_SESSION['id'])) {
    echo "<script>alert('非法操作，请先登陆！');location.href='login.html';</script>";
} else {
    ?>
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
        <title>doctor服务界面</title>
        <link href="style.css" rel="stylesheet" type="text/css">

    </head>
    <BODY>
    <?php
    include("online_user.php");

    ?>

    <div>

        <h1>已挂号病人信息</h1>

        <?php
        include("config.inc.php");

        $sql = "SELECT * FROM patient";
        $rowsult = $conn->query($sql);

        if ($rowsult->num_rows > 0) {
            echo "<TABLE>
    <TR class='tr_line0'>
        <Th align=center>id</Th>
        <Th align=center>姓名</Th>
        <Th align=center colspan='2'>操作</Th>
    </TR> \n";

            // 输出数据
            $i = 0;
            while ($row = $rowsult->fetch_assoc()) {
                $i++;
                if ($i % 2 == 1)
                    echo "\n<tr class=\"tr_line1\">";
                else
                    echo "\n<tr class=\"tr_line2\">";

                echo "\n<td> ", $row['id'], "</td>";
                echo "\n<td> ", $row['name'], "</td>";
                echo "\n<td> <A HREF='fill_case.php?id=", $row['id'], "&name=",$row['name'],"'>填写病历</A> </td>";
                echo "\n<td> <A HREF='check_case.php?id=", $row['id'], "&name=",$row['name'],"'>查看病历</A> </td>";
                echo "\n</tr>";
            }
            echo "\n</TABLE>";
        } else {
            echo "0 结果";
        }
        // 释放结果集
        mysqli_free_result($rowsult);
        $conn->close();
        ?>

    </div>

    </BODY>
    </html>

<?php
}
?>