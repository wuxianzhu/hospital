<?php
session_start();
if (isset($_SESSION['id'])) {
    echo "<script>alert('非法操作，请先登陆！');location.href='login.html';</script>";
} else {
  //  print_r($_POST);
    if(isset($_POST['submit'])) {
        include("config.inc.php");

        $sql = "INSERT INTO    case_table  (`id` ,`patientid` ,`doctorid` ,`case_history`)
           VALUES (NULL ,  '{$_POST['patientid']}',  '{$_SESSION['id']}',  '{$_POST['case_history']}')";
        //   echo $sql,"</p>";

        if ($conn->query($sql) === TRUE) {
            echo "新记录插入成功";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
    }
    else{}
    ?>
<html>
<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
</head>
<BODY>

<div>
    <h1>
        填写病历
    </h1>
    <FORM METHOD=POST ACTION="<? echo $PHP_SELF; ?>">
        患者id号：
        <INPUT TYPE="text" NAME="patientid"   size=11 maxlength=11  value='<?php echo $_GET['id']; ?>' readonly >
        <P> 患者姓名：
            <INPUT TYPE="text" NAME="name"    size=11 maxlength=8  value='<?php echo $_GET['name']; ?>' readonly>
        <P> 病情描述：
            <p>
            <textarea name="case_history" cols="30" rows="3">
   </textarea>
        <P>
            <INPUT TYPE="submit" name="submit" value="填写完毕！" >
    </FORM>
    </div>

</body>
</html>
<?php
}
?>