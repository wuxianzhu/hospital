<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="管理员"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="gb2312">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="../css/zengjia.css"/>
    <link href="../css/bootstrap.css" rel="stylesheet" />
    <!-- <link href="../css/glide.css" rel="stylesheet" /> -->
    <link href="../css/style.css" rel="stylesheet" />
    <title>管理修改密码</title>
</head>
<body>

<?php
include("../myHead.php");
?>


	<div class="myTotal">
	<div align="center" style="width: 810px;margin: 0px auto;padding: 50px;">
  <h3>修改密码</h3>

<?php
	include("../config.inc.php");
	$sql = "select * from manager where id=".$_SESSION['id'];
	$result = $conn->query($sql);
	$re = $result->fetch_assoc();
?>

<form action="managerxiugai1.php" method="post">
<table>
<tr>
	<td>id:</td>
	<td><input type="text" name="id" readonly value="<?php echo $re['id']; ?>"></td>
</tr>
<tr>
	<td>姓名:</td>
	<td><input type="text" name="name" readonly value="<?php echo $re['name']; ?>"></td>
</tr>
<tr>
	<td>请输入新密码:</td>
	<td><input type="text" name="password"></td>
</tr>
<tr>
	<td></td>
	<td><input type="submit" name="提交"></td>
</tr>
</table>
</form>

</div>
</div>

<?php
include("../myTail.php");
?>

</body>
</html>


<?php
}
?>