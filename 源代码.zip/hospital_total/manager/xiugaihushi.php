<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="管理员"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="gb2312">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>修改护士</title>
    <link rel="stylesheet" type="text/css" href="../css/zengjia.css"/>
    <link href="../css/bootstrap.css" rel="stylesheet" />
    <!-- <link href="../css/glide.css" rel="stylesheet" /> -->
    <link href="../css/style.css" rel="stylesheet" />
</head>

<body>

<?php
include("../myHead.php");
?>

<div class="myTotal">

<?php
include("../config.inc.php");
$num = $_GET['num'];
$sql1=" select id,name,password,office,introduce from nurse where id = ".$num; 
$res=$conn->query($sql1);
$data=$res->fetch_all();

echo '<div style="width: 510px;height:400px;margin: 0px auto;padding: 30px;">
    <h4 align="center">修改护士信息</h4>
    
    <form method="post" action="xiugaihushi1.php" >
        <table align="center"  border="1" cellpadding="2" cellspacing="1" style="word-wrap:break-word;table-layout:fixed;">

            <tr>
                <td width="100px" align="center" nowrap>工号<a>(不可修改)</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" name="工号" value='.$data[0][0].' required readonly>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>姓名</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" type="text" name="姓名" value='.$data[0][1].' required >
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>密码</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" type="password" name="密码" value='.$data[0][2].' required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>科室</td>
                <td width="100px"  nowrap><input style="width: 350px" type="text" name="科室" value='.$data[0][3].' required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>简介</td>
                <td width="100px"  nowrap><input style="width: 350px" type="text" name="简介" value='.$data[0][4].' required>
                </td>
            </tr>

            <tr>
                <td></td>
                <td>
                    <input type="submit" value="修改" >
<!--                    <button>注册</button>-->
                    
                </td>
            </tr>

        </table>
    </form>
</div>';



?>
</div>

<?php
include("../myTail.php");
?>

</body>
</html>


<?php
}
?>