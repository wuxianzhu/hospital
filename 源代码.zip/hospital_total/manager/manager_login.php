<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="管理员"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {

	function location($msg = '')
	{
	    echo '<script>alert("'.$msg.'"); window.location.href="manager_login2.php";</script>';
	}
	function location1($msg = '')
	{
	    echo '<script>alert("'.$msg.'"); window.location.href="manager_login.php";</script>';
	}

	include("../config.inc.php");
	$userExistsSQL = "SELECT * FROM manager WHERE   id = '{$_SESSION['id']}' AND name = '{$_SESSION['name']}' and password = '{$_SESSION['password']}';";
	$row = $conn->query($userExistsSQL)->fetch_assoc();

	if($row)
	{
	     location('登录成功');
	    return;
	}else{
	    location1('登录失败');
		
	}
}