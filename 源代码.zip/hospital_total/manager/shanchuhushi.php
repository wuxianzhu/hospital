<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="管理员"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
	header("Content-Type: text/html;charset=utf-8");
	error_reporting(0); //禁止错误输出
	include("../config.inc.php");
	 $sql=" delete  from  nurse  where id='{$_GET['num']}'"; 
	$res=$conn->query($sql);
	$mark=$conn->affected_rows;
	if($mark>0){
	 echo "<script>alert('删除成功')</script>";
	 echo "<script>window.location.href='chakanhushi.php'</script>";
	}else{
	 echo "<script>alert('删除失败')</script>";
	 echo "<script>window.location.href='chakanhushi.php'</script>";
	}
}
?>