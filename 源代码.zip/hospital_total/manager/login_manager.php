<?php
session_start();
if(isset($_POST['submit'])) {
    include("../config.inc.php");

    $id = $_POST['id'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $sql = "select * from manager  where id='$id'  and password='$password' ";
    $rowsult = $conn->query($sql);

    if ($rowsult->num_rows == 0) {
        echo "<script>alert('登录失败');</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=login_manager.php\" />";
    } else {
        echo "<script>alert('登录成功');</script>";
        $_SESSION['name'] = $name;
        $_SESSION['id'] = $id;
        $_SESSION['identity'] = "管理员";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=manager_login2.php\" />";
    }
    $conn->close();
}
else{}
?>
<!doctype html>
<html>
<head>
    <meta charset="gb2312">
    <title>管理员登录</title>
    <link href="../css/style2.css" rel="stylesheet" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />

    <link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
</head>

<body>

<?php
include("../myHead.php");
?>

<center>
    <div class="background">
        <div class="div1">
            <h1 style="font-size: 18pt">管理员登录账号</h1>
            <form method="post" action="<?php echo $PHP_SELF; ?>" >
                <table class="table1"  border="1" cellpadding="2" cellspacing="1" style="word-wrap:break-word;table-layout:fixed;">
                    <tr>
                        <td width="10px" align="center">id</td>
                        <td width="40px" >
                            <input  type="text" name="id" placeholder="请输入id号" required>
                        </td>
                    </tr>

                    <tr>
                        <td width="10px" align="center" >姓名</td>
                        <td width="40px" >
                            <input  type="text" name="name" placeholder="请输入姓名" required>
                        </td>
                    </tr>

                    <tr>
                        <td width="10px" align="center" nowrap>密码</td>
                        <td width="40px" nowrap>
                            <input  type="password" name="password" placeholder="请输入密码" required>
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>

                            <!--                    <button>注册</button>-->
                            <input type="submit" name="submit" value="登录" >
                        </td>
                    </tr>

                </table>
            </form>
        </div>
    </div>
</center>


<?php
include("../myTail.php");
?>
</body>
</html>