<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="管理员"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="gb2312">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>增加医生</title>
    <link rel="stylesheet" type="text/css" href="../css/zengjia.css"/>
    <link href="../css/bootstrap.css" rel="stylesheet" />
    <!-- <link href="../css/glide.css" rel="stylesheet" /> -->
    <link href="../css/style.css" rel="stylesheet" />
</head>
<body>

<?php
include("../myHead.php");
?>

<div class="myTotal">

<div style="width: 510px;height:400px;margin: 0px auto;padding: 100px;">
    <h4 align="center">增加医生</h4>
    <form method="post" action="zengjiayisheng1.php" >
        <table align="center"  border="1" cellpadding="2" cellspacing="1" style="word-wrap:break-word;table-layout:fixed;">

            <tr>
                <td width="100px" align="center" nowrap>工号</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" type="text" name="工号" placeholder="请输入工号" required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>姓名</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" type="text" name="姓名" placeholder="请输入姓名" required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>密码</td>
                <td width="100px" nowrap>
                    <input style="width: 350px" type="password" name="密码" placeholder="请输入密码" required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>科室</td>
                <td width="100px"  nowrap><input style="width: 350px" type="text" name="科室" placeholder="请输入科室" required>
                </td>
            </tr>

            <tr>
                <td width="100px" align="center" nowrap>简介</td>
                <td width="100px"  nowrap><input style="width: 350px" type="text" name="简介" placeholder="请输入简介" required>
                </td>
            </tr>

            <tr>
                <td></td>
                <td>
                    <input type="submit" value="增加" >
<!--                    <button>注册</button>-->
					
                </td>
            </tr>

        </table>
    </form>
</div>
</div>
<?php
include("../myTail.php");
?>
</body>
</html>

<?php
}
?>