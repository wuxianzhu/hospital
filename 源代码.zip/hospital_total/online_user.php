
 <style type="text/css">
	#user_info {bawidth:100pt;
        float:right;
        text-align:right;
        margin-top: 30pt;
        font-size: 18px;
        color: darkorange;
    }
 </style>
 
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
 
<div id="user_info">
<?php
//session_start()				 ;
if(isset($_SESSION['name']))
{
	echo "在线用户：". $_SESSION['name'];
    echo "<p>";
	echo  "<center> <a href='logout.php'>  [退出] </a></center>";
}
else {
	echo "在线用户：游客<p>";
	echo  "<center><a href='login.php'> 登录   </a>";
    echo  "<a href='patient/patient_register.php'> 注册 </a></center>";
}
?>
</div>