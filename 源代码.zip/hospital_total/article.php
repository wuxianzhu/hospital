<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />
    <title>星辰医院管理系统</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>

<body>
    
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临星辰医院管理系统网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="index.php"><img src="images/logotem.png" width="420" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("online_user.php");
                    ?>
                </div>
            </div>
        </div>

    <nav class="navbar navbar-static-top navbar-default">
        <div class="111" style="margin-left: 50px">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php"></a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php">网站首页</a></li>
                <li><a href="about.php">关于我们</a></li>
                <li><a href="article.php">新闻中心</a></li>
                <li><a href="login.php">服务中心</a></li>
                <li><a href=#>联系我们</a></li></ul>
</div>
</nav>
</header>
		
<!-- Banner -->
    <div class="banner" style="margin-top: 0px;">
        <div class="slider">   
                <li class="slider__item"><a target="_blank" title="1" href="" style="background-image: url(images/hospital2.jpg);background-size: cover;"><img src="images/banner-1.png"/></ a></li>
        </div>
    </div>
	
	   <div class="container">
        <div class="row">
            <div class="aboutustext">
                <div class="aboutustexttitle">
                    <div class="textBar">
                        <h2>新闻中心</h2>
                    </div>
					    <div class="articleBar">
                        <h3>文章列表：</h3>
                    </div>
                </div>
            </div>
        </div>
		
		 <div class="row">

            <div class="col-xs-12 col-sm-8 col-md-9" id="rightBox">

                <div class="col-sm-12 col-md-12 pad">
                    
                    <div class="nameList" style="margin-top:10px;">
                        <ul>
                        
                            <li>
                                
                                <a href="article_detail.php">1 卫健委发文：医疗废物专项整治来了</a>
                                <span class="time">2020-01-01</span>
                            </li>
                            
                            <li>
                                
                                <a href="article_detail.php">2 最新！一批药被医院停用</a>
                                <span class="time">2020-01-01</span>
                            </li>
                            
                            <li>
                                <a href="article_detail.php">3 医院“停车难”加剧“看病难”现象调查:堵车更堵心</a>
                                <span class="time">2020-01-01</span>
                            </li>
                            
                            <li>
                                <a href="article_detail.php">4 基层医生职称晋升有新规 涨工资不再难</a>
                                <span class="time">2020-01-01</span>
                            </li>
                            
                            <li>
                                <a href="article_detail.php">5 复旦版2019年度中国医院排行榜揭晓 高解春教授解读</a>
                                <span class="time">2020-01-01</span>
                            </li>
                              
                            <li>
                                <a href="article_detail.php">6 像防控院内感染一样重视伤医 容不得半点侥幸！</a>
                                <span class="time">2020-01-01</span>
                            </li>
                              
                            <li>
                                <a href="article_detail.php">7 国家药监局：100家医院成为国家药物滥用监测哨点	</a>
                                <span class="time">2020-01-01</span>
                            </li>
                              
                            <li>
                                <a href="article_detail.php">8 后疫情时代 二级医院或将逐渐不复存在</a>
                                <span class="time">2020-01-01</span>
                            </li>
                              
                            <li>
                                <a href="article_detail.php">9 必须科主任同意！三甲医院多点执业严管文件来了</a>
                                <span class="time">2020-01-01</span>
                            </li>
                              
                            <li>
                                <a href="article_detail.php">10 国家卫健委发文整顿 2.3万民营医院的未来将走向何处？</a>
                                <span class="time">2020-01-01</span>
                            </li>
                            
                        </ul>
				  </div>


                </div>
  		  </div>
        </div>
    </div>
    
	<div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
	
    <footer>
    
        <div class="copyright">
            <p>
                <a href="about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="login.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href=#>联系我们</a>
            </p>
            <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
        </div>

    </footer>
</body>
</html>

