<?php
echo '
<div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;clear: both"></div>
<footer style="clear: both">

    <div class="copyright">
        <p>
            <a href="../about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="../article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="doctor.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href=#>联系我们</a>
        </p>
        <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
    </div>

</footer>
    ';
?>