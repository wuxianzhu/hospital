<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />
    <title>星辰医院管理系统</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>

<body>
    
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临星辰医院管理系统网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="index.php"><img src="images/logotem.png" width="420" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("online_user.php");
                    ?>
                </div>
            </div>
        </div>

    <nav class="navbar navbar-static-top navbar-default">
        <div class="111" style="margin-left: 50px">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php"></a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php">网站首页</a></li>
                <li><a href="about.php">关于我们</a></li>
                <li><a href="article.php">新闻中心</a></li>
                <li><a href="login.php">服务中心</a></li>
                <li><a href=#>联系我们</a></li></ul>
                </div>
            </nav>
  </header>
    <!-- Banner -->
    <div class="banner" style="margin-top: 0px">
        <div class="slider">
            <!-- alt：图片路径失败时替换显示内容 -->			
                <li class="slider__item"><a target="_blank" title="1" href="" style="background-image:url(images/hospital.jpg);background-size: cover;"><img src="images/banner-1.png"/></a></li>
                <li class="slider__item"><a target="_blank" title="2" href="" style="background-image:url(images/hospital1.jpg);background-size: cover;"><img src="images/banner-1.png"/></a></li>
        </div>
    </div>

    <!-- 内容 -->
    <div class="container">
        <div class="row">

            <div class="col-xs-12 col-sm-9 col-md-9">
                <div class="aboutBox">
                    <div class="aboutTitle">
                        <h1>医院简介</h1>
                        <span>ABOUT US</span></div>
                    <section>
                        星辰医院是由网站开发与建设课程小组开发的医院网站，该网站主要面向客户，医生，护士，并且设有管理员。他们都能从医院的官网中获得该医院的相关信息，客户能在服务页面进行挂号与预约信息咨询；医生能够获得顾客挂号信息，并且拥有几乎电子病历功能；护士能获得预约心理咨询的顾客的相关信息；儿超级管理员能查看全部信息，并且增加或修改医生或护士信息，授予或删除他们的权限。
                    </section>
                </div>
            </div>

            <div class="col-xs-12 col-sm-3 col-md-3">
              <div class="serviceGroup">
                <div class="serviceBox">
                        <div class="title">网上服务</div>
                  </div>
                    <span class="serviceBox"><a href="login.php" type="button" class="registrationbtn">挂号预约</a></span>
					<p>1</p>
					<span class="serviceBox"><a href="login.php" type="button" class="registrationbtn">心咨预约</a></span></div>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="row">

            <div class="col-xs-12 col-sm-9 col-md-9">
                <div class="newsBox">
                    <div class="titleBar">
                        <h1>新闻中心</h1>
                        <span></span> <a class="rightMore" href="article.php">>></a>
                    </div>
                    <ul class="indexNewsList">
                        
                        <li class="col-xs-12 col-sm-6 col-md-6">
                            <a href="https://www.cn-healthcare.com/articlewm/20190612/content-1063240.html">
                                <div class="img" style="background-image: url(images/news/1.png)"></div>
                                <div class="txt">
                                    <span class="title">
                                       国家卫生健康委发文 22条政策力促民营医院发展	
                                    </span>
                                    <span class="time">[ 2019-06-12 ]</span>
                                    <p>
	                                    社会办医疗机构（以下简称社会办医）是我国医疗卫生服务体系的重要组成部分，是满足不同人群医疗卫生服务需求并为全社会提供更多医疗服务供给的重要力量。党中央、国务院高度重视发展社会办医，近年来出台了一系列政策措施，不断深化改革、改善办医环境，取得了积极成效...
                                    </p>
                                </div>
                            </a>
                        </li>
                            
                        <li class="col-xs-12 col-sm-6 col-md-6">
                            <a href="https://www.cn-healthcare.com/articlewm/20190130/content-1045450.html">
                                <div class="img" style="background-image: url(images/news/2.png)"></div>
                                <div class="txt">
                                    <span class="title">
                                        国务院发文 公立医院迎来大变革
                                    </span>
                                    <span class="time">[ 2019-01-30 ]</span>
                                    <p>
	                                    国务院办公厅印发《关于加强三级公立医院绩效考核工作的意见》（下文简称《意见》），要求三级公立医院先行建立绩效考核指标体系，同时逐步推开对所有医疗机构的绩效考核...
                                    </p>
                                </div>
                            </a>
                        </li>
                            
                        <li class="col-xs-12 col-sm-6 col-md-6">
                            <a href="https://www.cn-healthcare.com/article/20201127/content-546764.html">
                                <div class="img" style="background-image: url(images/news/3.png)"></div>
                                <div class="txt">
                                    <span class="title">
                                        钟南山：已出现同患流感和新冠肺炎病例
                                    </span>
                                    <span class="time">[ 2020-11-27 ]</span>
                                    <p>
	                                    在阻断新冠病毒传播上，钟南山给出两个重要途径，一是一旦出现本土病例，局部地区的全民核酸检测十分必要（预防社区传播）；二是佩戴口罩能有效预防传播，外科口罩和N95口罩可减少飞沫和气溶胶传播...
                                    </p>
                                </div>
                            </a>
                        </li>
                            
                        <li class="col-xs-12 col-sm-6 col-md-6">
                            <a href="https://www.cn-healthcare.com/article/20201123/content-546476.html">
                                <div class="img" style="background-image: url(images/news/4.png)"></div>
                                <div class="txt">
                                    <span class="title">
                                       执业药师配备最新规则发布！明年起实施
                                    </span>
                                    <span class="time">[ 2020-11-23 ]</span>
                                    <p>
	                                    医药经济报:我国执业药师缺口仍然较大。11月20日，国家药监局正式对外发布了“关于规范药品零售企业配备使用执业药师的通知”（以下简称《通知》）...
                                    </p>
                                </div>
                            </a>
                        </li>
                            
                    </ul>
                </div>
            </div>
			
            <div class="col-xs-12 col-sm-3 col-md-3">
                <div class="contactBox" style="padding:10px;"></div>
            </div>
			
        </div>
    </div>

    <div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>

 
   
    <footer>
    
        <div class="copyright">
            <p>
                <a href="about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="login.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href=#>联系我们</a>
            </p>
            <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
        </div>

    </footer>

</body>

 <script type="text/javascript">
        // index：索引， len：长度
        var index = 0, len;
        // 类似获取一个元素数组
        var imgBox = document.getElementsByClassName("slider__item");
        len = imgBox.length;
        imgBox[index].style.display = 'block';
        // 逻辑控制函数
        function slideShow() {
            index ++;
            // 防止数组溢出
            if(index >= len) index = 0;
            // 遍历每一个元素
            for(var i=0; i<len; i++) {
                imgBox[i].style.display = 'none';
            }
            // 每次只有一张图片显示
            imgBox[index].style.display = 'block';
        }
        
        // 定时器，间隔5s切换图片
        setInterval(slideShow, 3000);
        
    </script>
</html>
