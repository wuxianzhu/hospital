<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />
    <title>星辰医院管理系统</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>

<body>
    
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临星辰医院管理系统网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="index.php"><img src="images/logotem.png" width="420" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("online_user.php");
                    ?>
                </div>
            </div>
        </div>

    <nav class="navbar navbar-static-top navbar-default">
        <div class="111" style="margin-left: 50px">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php"></a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php">网站首页</a></li>
                <li><a href="about.php">关于我们</a></li>
                <li><a href="article.php">新闻中心</a></li>
                <li><a href="login.php">服务中心</a></li>
                <li><a href=#>联系我们</a></li></ul>
            </div>
        </nav>
    </header>

		
<!-- Banner -->
    <div class="banner" style="margin-top: 0px;">
        <div class="slider">   
                <li class="slider__item"><a target="_blank" title="1" href="" style="background-image: url(images/hospital2.jpg);background-size: cover;"><img src="images/banner-1.png"/></ a></li>
        </div>
    </div>
	
	   <div class="container">
        <div class="row">
            <div class="aboutustext">
                <div class="aboutustexttitle">
                    <div class="textBar">
                        <h2>医院概况</h2>
                    </div>
                </div>
            </div>
			
			<p style="text-align:left;line-height:2.5em;">　
				<span style="font-family:微软雅黑;font-size:14px;color:#444444;">　星辰医院是由网站开发与建设课程小组开发的医院网站，该网站主要面向客户，医生，护士，并且设有管理员。他们都能从医院的官网中获得该医院的相关信息，客户能在服务页面进行挂号与预约信息咨询；医生能够获得顾客挂号信息，并且拥有几乎电子病历功能；护士能获得预约心理咨询的顾客的相关信息；而超级管理员能查看全部信息，并且增加或修改医生或护士信息，授予或删除他们的权限。<br> &nbsp;</span></p>
        </div>
    </div>

	<div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
	
    <footer>
    
        <div class="copyright">
            <p>
                <a href="about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="login.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href=#>联系我们</a>
            </p>
            <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
        </div>

    </footer>
</body>
</html>
