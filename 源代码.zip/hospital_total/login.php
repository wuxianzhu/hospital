<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="gb2312">
    <title>医院管理系统</title>
    <link href="css/style2.css" rel="stylesheet" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />

    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>
<style type="text/css">
    #user_info {bawidth:100pt;
        float:right;
        text-align:right;
        margin-top: 30pt;
        font-size: 18px;
        color: darkorange;
    }
 </style>
<body>
<header>

    <div class="topBox">
        <div class="borderBottom">
            <div class="container">
                <div class="welcomeBox">欢迎光临xx医院网站</div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="index.php"><img src="images/logotem.png" width="364" height="84"/></a></div>
                <div class="col-xs-6 col-sm-3 col-md-2">
                    <div class="tel">
                        <img src="images/tel.gif" alt="" /><br />400-8888-8888
                    </div>
                </div>

                    <?php
                    include("online_user.php");
                    ?>

            </div>
        </div>
    </div>

    <nav class="navbar navbar-static-top navbar-default">
        <div class="111" style="margin-left: 50px">
            <div class="navbar-header">
                <a class="navbar-brand" href="index.php"></a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="index.php">网站首页</a></li>
                <li><a href="about.php">关于我们</a></li>
                <li><a href="article.php">新闻中心</a></li>
                <li><a href="login.php">服务中心</a></li>
                <li><a href=#>联系我们</a></li></ul></div>
</nav>
</header>
        <center>
<div class="background">
<div class="div1">
    <h2>欢迎使用医院管理系统</h2>
    <h3>请选择您的身份</h3>
    <p></p>
    <script>
        function patient()
        {
            window.location.href="patient/login_patient.php"
        }
        function doctor()
        {
            window.location.href="doctor/login_doctor.php"
        }
        function nurse()
        {
            window.location.href="nurse/login_nurse.php"
        }
        function manager()
        {
            window.location.href="manager/login_manager.php"
        }
    </script>
    <button class="button1"  onclick="patient()">患者</button><td></td>
    <button  class="button1" onclick="doctor()">医生</button><p></p><p></p>
    <button class="button1" onclick="nurse()">护士</button><td></td>
    <button  class="button1" onclick="manager()">管理员</button><p></p><p></p>
</div>
</div>
</center>
        <div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
        <footer>

            <div class="copyright">
                <p>
                    <a href="about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href="article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href=#>服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                    <a href=#>联系我们</a>
                </p>
                <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
            </div>

        </footer>
</body>
</html>