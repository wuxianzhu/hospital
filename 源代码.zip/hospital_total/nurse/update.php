<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="护士"))) {
    echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
    ?>

    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
        <title>护士修改个人信息</title>
        <link href="../css/style2.css" rel="stylesheet" type="text/css">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="applicable-device" content="pc" />

        <link href="../css/bootstrap.css" rel="stylesheet" />
        <link href="../css/glide.css" rel="stylesheet" />
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <BODY>
    <?php include("../myHead.php");
    ?>
    <center>
    <div class="background">
    <div class="div1">

<?php
require_once "../config.inc.php";
if (isset($_REQUEST['sub'])) { //更新数据
    $sql = "update nurse set password='" . $_REQUEST['password'] . "',";
    $sql = $sql . " introduce='" . $_REQUEST['introduce'] . "'";
    $sql = $sql . " where id=" . $_SESSION['id'] . ";";
    $update_result = $conn->query($sql);
    if ($update_result) {
        echo "<script>alert('修改成功')</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=nurse.php\" />";
    }
    else {
        echo "<script>alert('修改失败')</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=update.php\" />";
    }
}

$sql = "select * from nurse where id={$_SESSION['id']}";
$result = $conn->query($sql);
$re = $result->fetch_assoc();
$conn->close();
?>


        <h1>修改个人信息</h1>

        <FORM class="form1" METHOD=POST ACTION="<? echo $PHP_SELF; ?>">

            id号：<INPUT TYPE="text" NAME="id" size=11  value='<?php echo $re['id']; ?>' readonly>

            <P><P>
                姓名：<INPUT TYPE="text" NAME="name" size=11
                          value='<?php echo $re['name']; ?>' readonly>
            <P>
                科室：<INPUT TYPE="text" NAME="office" size=11  value='<?php echo $re['office']; ?>' readonly>
            <P>
                密码：<INPUT TYPE="text" NAME="password" size=11 maxlength=11 >
            <P>
            <P>
                个人简介：
                <p><textarea type="text" NAME="introduce" cols="20" rows="3" maxlength=200 >
                    </textarea>

            <P>
                <INPUT TYPE="submit" value="确定" name="sub">
        </FORM>

    </div>
    </div>
    </center>
    <?php include("../myTail.php");
    ?>
    </BODY>
    </html>
<?php
}
?>