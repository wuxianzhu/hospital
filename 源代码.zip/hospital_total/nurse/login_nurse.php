<?php
session_start();
//  print_r($_POST);
if(isset($_POST['submit'])) {
    include("../config.inc.php");

    $id = $_POST['id'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $sql = "select * from nurse  where id='$id'  and password='$password' ";
    $rowsult = $conn->query($sql);

    if ($rowsult->num_rows == 0) {
        echo "<script>alert('登录失败');</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=login_nurse.php\" />";
    } else {
        echo "<script>alert('登录成功');</script>";
        $_SESSION['name'] = $name;
        $_SESSION['id'] = $id;
        $_SESSION['identity'] = "护士";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=nurse.php\" />";
    }

    $conn->close();
}
else{}
?>
<!doctype html>
<html>
<head>
    <meta charset="gb2312">
    <title>护士登录</title>
    <link href="../css/style2.css" rel="stylesheet" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />

    <link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/glide.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
</head>

<body>

<?php include("../myHead.php");
?>
<center>
    <div class="background">
        <div class="div1">
            <h1 align="center">护士登录账号</h1>
            <form class="form1" method="post" action="<?php echo $PHP_SELF; ?>" >

               id号：

                            <input width="40px" type="text" name="id" placeholder="请输入id号" required>
                <p>
                    <p>
                    姓名：

                            <input width="40px" type="text" name="name" placeholder="请输入姓名" required>
                <p>
                密码：

                <input width="40px" type="password" name="password" placeholder="请输入密码" required>
                <p>
                            <input type="submit" name="submit" value="登录" >
            </form>
        </div>
    </div>
</center>
<?php include("../myTail.php");
?>
</body>
</html>