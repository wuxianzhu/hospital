<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="护士"))) {
    echo "<script>alert('非法操作，请先登陆！');location.href='../login.php';</script>";
    exit();
}else {
    if (isset($_GET['id'])) {
        require_once "../config.inc.php";

        $sql = "update appointment set state='1' where id='{$_GET['id']}'";
        $update_result = $conn->query($sql);
        if ($update_result)
            echo "<script>alert('已同意 {$_GET['name']} 的心理辅导预约')</script>";
        else
            echo "<script>alert('同意 {$_GET['name']}  的心理辅导预约失败')</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=agree_appointment1.php\" />";
    }else{}
}
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
    <title>同意心理辅导预约</title>

</head>
<BODY>
</BODY>
</html>