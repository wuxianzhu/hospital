<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="护士"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
    <title>同意心理辅导预约</title>
    <link href="../css/style2.css" rel="stylesheet" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />

    <link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
</head>
<BODY>
<?php include("../myHead.php");
?>

<center>
<div class="background">
<div class="div1">
    <h1>已申请心理辅导预约病人信息</h1>

    <?php
    include("../config.inc.php");

    $sql = "SELECT appointment.id,appointment.patientid,patient.name FROM appointment,patient where appointment.nurseid={$_SESSION['id']} and patient.id=appointment.patientid and  appointment.state='0'";
    $rowsult = $conn->query($sql);

    if ($rowsult->num_rows > 0) {
        echo "<TABLE class='table1'>
    <TR class='tr_line0'>
        <Th align=center>编号</Th>
        <Th align=center>病人id号</Th>
        <Th align=center >病人姓名</Th>
         <Th align=center >操作</Th>
    </TR> \n";

        // 输出数据
        while ($row = $rowsult->fetch_assoc()) {
                echo "\n<tr>";

            echo "\n<td> ", $row['id'], "</td>";
            echo "\n<td> ", $row['patientid'], "</td>";
            echo "\n<td> ", $row['name'], "</td>";
            echo "\n<td> <A HREF='agree_appointment.php?id=", $row['id'], "&name=",$row['name'],"'>同意</A> </td>";
            echo "\n</tr>";
        }
        echo "\n</TABLE>";
    } else {
        echo "0 结果";
    }
    // 释放结果集
  //  mysqli_free_result($rowsult);
    $conn->close();
    ?>
</div>
</div>
</center>
        <?php include("../myTail.php");
        ?>
</BODY>
</html>

<?php
}
?>