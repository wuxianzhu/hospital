<?php
session_start();
if (isset($_SESSION['id'])) {
echo "<script>alert('非法操作，请先登陆！');location.href='login.html';</script>";
} else {
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
    <title>同意心理辅导预约</title>
    <link href="style.css" rel="stylesheet" type="text/css">

</head>
<BODY>
<?php
include("online_user.php");

?>

<div>

    <h1>已申请心理辅导预约病人信息</h1>

    <?php
    include("config.inc.php");

    $sql = "SELECT * FROM appointment";
    $rowsult = $conn->query($sql);

    if ($rowsult->num_rows > 0) {
        echo "<TABLE>
    <TR class='tr_line0'>
        <Th align=center>编号</Th>
        <Th align=center>病人id号</Th>
        <Th align=center >病人姓名</Th>
         <Th align=center >操作</Th>
    </TR> \n";

        // 输出数据
        $i = 0;
        while ($row = $rowsult->fetch_assoc()) {
            $i++;
            if ($i % 2 == 1)
                echo "\n<tr class=\"tr_line1\">";
            else
                echo "\n<tr class=\"tr_line2\">";

            $sql1 = "SELECT * FROM patient where id='{$row['patientid']}'";
            $rowsult1 = $conn->query($sql1);
            $row1 = $rowsult1->fetch_assoc();

            echo "\n<td> ", $row['id'], "</td>";
            echo "\n<td> ", $row['patientid'], "</td>";
            echo "\n<td> ", $row1['name'], "</td>";
            echo "\n<td> <A HREF='agree_appointment.php?id=", $row['id'], "'>同意</A> </td>";
            echo "\n</tr>";
        }
        echo "\n</TABLE>";
    } else {
        echo "0 结果";
    }
    // 释放结果集
    mysqli_free_result($rowsult);
    $conn->close();
    ?>

</div>

</BODY>
</html>

<?php
}
?>