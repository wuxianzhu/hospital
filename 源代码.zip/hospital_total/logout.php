<?php
session_start();
session_unset();
session_destroy() ;
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="1; url=index.php" />
1秒后退出....