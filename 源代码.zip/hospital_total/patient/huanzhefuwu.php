<?php
session_start();

if (!((isset($_SESSION['id']))&($_SESSION['identity']=="病人"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>


<!doctype html>
<html>
<head>
    <meta charset="gb2312">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>患者服务界面</title>
    <link rel="stylesheet" type="text/css" href="../css/manager.css"/>

    <link href="../css/bootstrap.css" rel="stylesheet" />
    <!-- <link href="../css/glide.css" rel="stylesheet" /> -->
    <link href="../css/style.css" rel="stylesheet" />
</head>

<body>

<?php
include("../myHead.php");
?>
<div class="myTotal" style="padding: 50px;">
<div  style="width: 810px; margin: 0px auto;">
  <h2>欢迎回来</h2><p></p>
  <h3>您可以：</h3>
  	<button onclick="yisheng()" class="btn_ckys">预约挂号以及心理咨询</button>
  	<button onclick="hushi()" class="btn_ckhs">查看个人病历</button>
    <button onclick="huanzhexiugai()" class="huanzhexiugai">修改密码</button>
    <p></p>
    <p></p>
  </div>
    </div>

    <?php
    include("../myTail.php");
    ?>



    <script type="text/javascript">
	function yisheng(){
  		window.location.href="yuyuefuwu.php?office="+"default";
  	}
  	function hushi(){
  		window.location.href="chakanbingli.php";
  	}
    function huanzhexiugai(){
      window.location.href="huanzhexiugai.php";
    }




</script>

</body>
</html>

<?php
}
?>