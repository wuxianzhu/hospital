<?php
session_start();

    //  print_r($_POST);
    if(isset($_POST['submit'])) {
        include("../config.inc.php");

        $sql = "INSERT INTO    patient  (`id` ,`name` ,`password`)
           VALUES (NULL ,  '{$_POST['name']}',  '{$_POST['password']}')";
        //   echo $sql,"</p>";case_history

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('注册成功');</script>";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $sql1="select * from patient where name='{$_POST['name']}'and password='{$_POST['password']}'";
        $rowsult1 = $conn->query($sql1);

      while( $row1 = $rowsult1->fetch_assoc()){
          $id=$row1['id'];
      }
           echo "<script>alert('您的id号为{$id}，请记住它并用它登录');</script>";
        $conn->close();
    }
    else{}
    ?>
    <html>
    <head>
        <link href="../css/style2.css" rel="stylesheet" type="text/css">
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="applicable-device" content="pc" />

        <link href="../css/bootstrap.css" rel="stylesheet" />
        <link href="../css/style.css" rel="stylesheet" />
    </head>
    <BODY>
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临xx医院网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="../index.php"><img src="../images/logotem.png" width="364" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="../images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("../online_user1.php");
                    ?>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-static-top navbar-default">
            <div class="111" style="margin-left: 50px">
                <div class="navbar-header">
                    <a class="navbar-brand" href="../index.php"></a>
                </div>
                <ul class="nav navbar-nav">
                    <li><a href="../index.php">网站首页</a></li>
                    <li><a href="../about.php">关于我们</a></li>
                    <li><a href="../article.php">新闻中心</a></li>
                    <li><a href="login_patient.php">服务中心</a></li>
                    <li><a href=#>联系我们</a></li></ul></div>
    <center>
    <div class="background">
    <div class="div1">
<h1>
            注册
</h1>
        <FORM class="form1" METHOD=POST ACTION="<?php echo $PHP_SELF; ?>">
            姓名：
            <INPUT TYPE="text" NAME="name"   size=11 maxlength=11  >
            <P> <P>密码：
                <INPUT TYPE="text" NAME="password"    size=11 maxlength=8  >
            <P>
                <INPUT TYPE="submit" name="submit" value="注册" >
        </FORM>
    </div>
    </div>
    </center>

            <?php
            include("../myTail.php");
            ?>

    </body>
    </html>
