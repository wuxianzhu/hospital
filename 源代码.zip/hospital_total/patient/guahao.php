<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="病人"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
	header("Content-Type: text/html;charset=utf-8");
	error_reporting(0); //禁止错误输出
	include("../config.inc.php");

	$sql2="insert into registration (patientid, doctorid) values('{$_SESSION['id']}','{$_GET['num']}');"; 
	$res=$conn->query($sql2);
	$mark=$conn->affected_rows;
	if($mark>0){
		echo "<script>alert('挂号成功')</script>";
		echo '<script>window.location.href="yuyuefuwu.php?office="+"default"</script>';
	}else{
	 	echo "<script>alert('挂号失败')</script>";
		echo '<script>window.location.href="yuyuefuwu.php?office="+"default"</script>';
	}
}
?>