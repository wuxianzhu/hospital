<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="病人"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="gb2312">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>查看个人病历</title>
    <link rel="stylesheet" type="text/css" href="../css/yishenghushi.css"/>
    <link href="../css/bootstrap.css" rel="stylesheet" />
    <!-- <link href="../css/glide.css" rel="stylesheet" /> -->
    <link href="../css/style.css" rel="stylesheet" />
    
</head>

<body>


<?php
include("../myHead.php");
?>


<div class="myTotal" >
	<div  style="width: 510px;margin: 0px auto;padding: 50px;">
		<h3>您的病历信息如下：</h3><p></p>
		<button onclick="fanhui()" class="btn_fanhui">返回</button><p></p><p></p>

<?php
header("Content-Type: text/html;charset=utf-8");
error_reporting(0); //禁止错误输出
include("../config.inc.php");
$sql=" select case_history from case_table where patientid=".$_SESSION['id']; 
$res=$conn->query($sql);
$data=$res->fetch_all();

$sql2 = "select name,office from doctor where id in (
	select doctorid from case_table where patientid =".$_SESSION['id']."
)";
$result=$conn->query($sql2);
$data2 = $result->fetch_all();

echo "<table border='1' class='lwltable'><tr><th>医生姓名</th><th>医生科室</th><th>病历</th></tr>";//构造表头
$i = 0;
foreach($data as $v){
	echo "<tr>";
	echo "<td>".$data2[$i][0]."</td>";
	echo "<td>".$data2[$i][1]."</td>";
	echo "<td>".$v[0]."</td>";
	echo "</tr>";
	$i++;
}
echo "</table>";
?>

	
	
	</div>
</div>


<?php 
include("../myTail.php"); 
?>

<script>
function fanhui() {
	window.location.href="huanzhefuwu.php";
}
</script>
</body>
</html>

<?php
}
?>