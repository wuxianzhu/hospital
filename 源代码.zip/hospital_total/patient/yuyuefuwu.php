<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="病人"))) {
echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>患者服务</title>
<link rel="stylesheet" type="text/css" href="../css/patient.css"/>
<link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/glide.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
</head>


<body>


<?php
include("../myHead.php");
?>

<div class="myTotal">

<div align="center" style="width: 810px;margin: 0px auto;"> 
		<h1>请选择您所需要预约的服务</h1>

<img src="../images/doctor.jpg" width="810px">

<?php
	include("../config.inc.php");
	$sql="select distinct office from doctor"; 
	$res=$conn->query($sql);
	$data=$res->fetch_all();

	# sidebar
	echo '<div id="lwlsidebar" align="left">
	<table id="keshi" cellpadding="10">';
	foreach ($data as $v) {
		echo "<tr><td><a href='yuyuefuwu.php?office=".$v[0]."' style='display: block;'>".$v[0]."</a></td></tr>";
	}
	echo "<tr><td><a href='yuyuefuwu.php?office=心理咨询' style='display: block;'>心理咨询</a></td></tr>";
	echo '</table>';
	echo '</div>';

	# 当前位置
	if ($_GET['office'] != "default") {
		echo '<div class="dangqianweizhi">
		<p align="left" ><font size="4pt" >当前位置>><a href="huanzhefuwu.php">患者服务</a>>>预约服务>><a href="yuyuefuwu.php?office='.$_GET['office'].'">'.$_GET['office'].'</a></font></p>
		</div>';
	} else {
		echo '<div class="dangqianweizhi">
		<p align="left" ><font size="4pt" >当前位置>><a href="huanzhefuwu.php">患者服务</a>>>预约服务>><a href="yuyuefuwu.php?office='.$data[0][0].'">'.$data[0][0].'</a></font></p>
		</div>';
	}

	# 医生列表
	if($_GET['office'] == "心理咨询"){
		echo "<div>
		<table id='doctors'>
		<tr><th>护士姓名</th>
		<th>护士简介</th>
		<th>预约心理咨询</th></tr>";

		$sql2=" select id,name,password,office,introduce from nurse"; 
		$res=$conn->query($sql2);
		$data2=$res->fetch_all();
		
		foreach($data2 as $v){
			echo "<tr>";
			echo "<td>".$v[1]."</td>";
			echo "<td>".$v[2]."</td>";
			echo "<td><button onclick='yuyue(".$v[0].")' class='btn_yygh'>预约心理咨询</button> </td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "</div>";
		
	}else{
		echo "<div>
		<table id='doctors'>
		<tr><th>医生姓名</th>
		<th>医生简介</th>
		<th>预约挂号</th></tr>";
		if($_GET['office'] == 'default'){
			$sql2=" select id,name,password,office,introduce from doctor where office='".$data[0][0]."'";
		}else{
			$sql2=" select id,name,password,office,introduce from doctor where office='".$_GET['office']."'";
		}
		
		 
		$res=$conn->query($sql2);
		$data2=$res->fetch_all();

		foreach($data2 as $v){
			echo "<tr>";
			echo "<td>".$v[1]."</td>";
			echo "<td>".$v[2]."</td>";
			echo "<td><button onclick='guahao(".$v[0].")' class='btn_yygh'>预约挂号</button> </td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "</div>";
	}
?>
</div>

</div>

<?php
include("../myTail.php");
?>


<script>
function guahao($num){
	window.location.href="guahao.php?num="+$num;
}
function yuyue($num){
	window.location.href="yuyue.php?num="+$num;
}

</script>
</body>
</html>


<?php
}
?>