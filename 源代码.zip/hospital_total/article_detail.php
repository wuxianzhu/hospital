<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />
    <title>星辰医院</title>
    
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
</head>

<body>
    
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临星辰医院网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="index.php"><img src="images/logotem.png" width="364" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("online_user.php");
                    ?>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-static-top navbar-default">
                <div class="navbar-header">  
                    <a class="navbar-brand" href="index.php"></a>
                </div>
                    <ul class="nav navbar-nav">
                        <li><a href="index.php">网站首页</a></li>
                        <li><a href="about.php">关于我们</a></li>
                        <li><a href="article.php">新闻中心</a></li>
                        <li><a href="login.php">服务中心</a></li>
                        <li><a href=#>联系我们</a></li></ul>

		
		    <!-- Banner -->
    <!-- Banner -->
    <div class="banner">
        <div class="slider">			
                <li class="slider__item"><a target="_blank" title="1" href="" style="background-image:url(images/hospital2.jpg)"><img src="images/banner-1.png"/></a></li>
        </div>
    </div>
	
		   <div class="container">
        <div class="row">
            <div class="aboutustext">
                <div class="aboutustexttitle">
                    
                        <h2>新闻中心</h2>
						<h3>又有大三甲被贴举报信 医药代表怎么看？</h3>
                   
                </div>
            </div>
			
			<p style="text-align:left;line-height:2.5em;">　
				<span style="font-family:微软雅黑;font-size:14px;color:#444444;">　
				<p>		业内有消息称，10月28日，广州某三甲医院也被贴举报信。</p>

<p>该举报信阐述的举报信内容，主要是广州某医院的医院医生收受医药代表贿赂拿药品回扣严重违规违法现象。该企业医药代表在信息科买医生用药数据每月给医生药品回扣，三种产品分别给予药品回扣8元/盒、12元/盒、12元/盒，医生通过每月销量几千盒牟取暴利。</p>

<p>说到举报，在此之前，已有多家三甲医院被贴了匿名举报信，均与药品回扣有关。</p>

<p>而在数日前，西安也有两家医院被贴实名举报信。据了解，针对网上传播的个别医疗器械公司涉嫌向西安两家医院有关人员进行商业贿赂的举报，西安市卫健委已在官网通报，表示高度重视该事件，已成立调查组并严格依法依纪依规进行调查核实。对违法违纪行为，一经查实，严肃处理，并及时公开调查处理结果。</p>

<p>举报信一般都是直指医院部分科室医生和医药代表存在非正常销售关系，从中带金销售，有的还表示已将相关情况发给省巡视组、市纪检委、医院领导处等相关单位。据业内人士透露，针对相关举报，医院采购人员正在被调查，已有药企被停药。</p>

<p>举报应该走正规渠道上述举报是否真实有待考究，在此不予置评。不过有业内人士向赛柏蓝表示，近几个月以来医院频繁出现举报信，有可能是医药企业竞争对手之间抗衡的一种行为，这样的行为其实是不可取的。</p>

<p>值得一提的是，严查药品回扣、严打医疗腐败确实是今年有关部门的风向标。目前，有关部门已经在开展医疗反腐也倡导大家举报不合规的现象，但是务必要走正规的渠道。</p>

<p>近日，国家卫健委综合监督司发布公告称，国家卫健委定于9月下旬会同相关部门组织开展医疗卫生行业综合监管督察，对北京、河北等19个省（区、市）和新疆生产建设兵团进行实地督察。</p>

<br> &nbsp;</span></p>
        </div>
    </div>
	
	<div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
	
    <footer>
    
        <div class="copyright">
            <p>
                <a href="about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="login.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href=#>联系我们</a>
            </p>
            <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
        </div>

    </footer>
</nav>
</body>
</html>

