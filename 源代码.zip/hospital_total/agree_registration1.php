<?php
session_start();
if (isset($_SESSION['id'])) {
    echo "<script>alert('非法操作，请先登陆！');location.href='login.html';</script>";
    exit();
}
require_once "config.inc.php";

    $sql = "update registration set state='同意' id= where id='{$_GET['id']}';
    $sql = $sql . " name='" . $_REQUEST['name'] . "',";
    $sql = $sql . " college='" . $_REQUEST['college'] . "'";
    $sql = $sql . " where id=" . $_REQUEST['id'] . ";";
    echo $sql;
    $update_result = $conn->query($sql);
    if ($update_result)
        echo "<script>alert('更新  id={$_POST['id']}  成功')</script>";
    else
        echo "<script>alert('更新  id={$_POST['id']}  失败')</script>";


$sql = "select * from student where id=" . $_REQUEST['id'];
echo "\n", $sql;
$result = $conn->query($sql);
//while($row = $rowsult->fetch_assoc()) {

$re = $result->fetch_assoc();
$conn->close();

?>