<?php
echo '
<header>

    <div class="topBox">
        <div class="borderBottom">
            <div class="container">
                <div class="welcomeBox">欢迎光临星辰医院管理系统网站</div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="../index.php"><img src="../images/logotem.png" width="364" height="84"/></a></div>
                <div class="col-xs-6 col-sm-3 col-md-2">
                    <div class="tel">
                        <img src="../images/tel.gif" alt="" /><br />400-8888-8888
                    </div>
                </div>
';
                include("../online_user1.php");

      echo '      </div>

        </div>
    </div>

    <nav class="navbar navbar-static-top navbar-default">
        <div class="111" style="margin-left: 50px">
            <div class="navbar-header">
                <a class="navbar-brand" href="../index.php"></a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="../index.php">网站首页</a></li>
                <li><a href="../about.php">关于我们</a></li>
                <li><a href="../article.php">新闻中心</a></li>
                <li><a href="../login.php">服务中心</a></li>
                <li><a href=#>联系我们</a></li></ul>
            </div>
    </nav>
</header>';
?>