<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="医生"))) {
    echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
} else {
    ?>

    <!doctype html>
    <html>
    <head>
        <meta charset="gb2312">
        <title>医生服务</title>
        <link href="../css/style2.css" rel="stylesheet" type="text/css">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="applicable-device" content="pc" />

        <link href="../css/bootstrap.css" rel="stylesheet" />
        <link href="../css/style.css" rel="stylesheet" />
    </head>

    <body>
    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临xx医院网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href="../index.php"><img src="../images/logotem.png" width="364" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="../images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("../online_user1.php");
                    ?>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-static-top navbar-default">
            <div class="111" style="margin-left: 50px">
                <div class="navbar-header">
                    <a class="navbar-brand" href="../index.php"></a>
                </div>
                <ul class="nav navbar-nav">
                    <li><a href="../index.php">网站首页</a></li>
                    <li><a href="../about.php">关于我们</a></li>
                    <li><a href="../article.php">新闻中心</a></li>
                    <li><a href="doctor.php">服务中心</a></li>
                    <li><a href=#>联系我们</a></li></ul></div>

    <center>
        <div class="background">
            <div class="div1">
                <h1 style="font-size: 18pt">请选择您所需要的服务</h1>
                <p></p>
                <script>
                    function ckygh() {
                        window.location.href = "yiguahao.php"
                    }
                    function tygh() {
                        window.location.href = "agree_registration.php"
                    }

                    function xgxx() {
                        window.location.href = "update.php"
                    }
                </script>
                <button class="button1" style="width:200px;height:50px" onclick="ckygh()">查看已挂号病人</button>
                <td></td>
                <p></p>
                <button class="button1" style="width:200px;height:50px" onclick="tygh()">查看已申请挂号病人</button>
                <p></p>
                <button class="button1" style="width:200px;height:50px" onclick="xgxx()">修改个人信息</button>
                <td></td>

            </div>
        </div>
    </center>
    <div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
    <footer>

        <div class="copyright">
            <p>
                <a href="../about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="../article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href="doctor.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
                <a href=#>联系我们</a>
            </p>
            <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
        </div>

    </footer>
    </nav>
    </body>
    </html>
<?php
}
?>