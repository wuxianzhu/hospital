<?php
session_start();
if (!((isset($_SESSION['id']))&($_SESSION['identity']=="医生"))) {
    echo "<script>alert('非法操作，请先登录！');location.href='../login.php';</script>";
    exit();
}else {
    if(isset($_GET['id'])) {
        require_once "../config.inc.php";

        $sql = "update registration set state='1' where id='{$_GET['id']}'";
        echo $sql;
        $update_result = $conn->query($sql);
        if ($update_result)
            echo "<script>alert('已同意 {$_GET['name']} 的挂号申请')</script>";
        else
            echo "<script>alert('同意 {$_GET['name']}  的挂号失败')</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=agree_registration.php\" />";
    }
    ?>
    <html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
        <title>同意挂号</title>
        <link href="../css/style2.css" rel="stylesheet" type="text/css">

    </head>
    <BODY>
    </BODY>
    </html>
<?php
}
?>