<?php
session_start();
//  print_r($_POST);
if(isset($_POST['submit'])) {
    include("../config.inc.php");

    $id = $_POST['id'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $sql = "select * from doctor  where id='$id'  and password='$password' ";
    $rowsult = $conn->query($sql);

    if ($rowsult->num_rows == 0) {
        echo "<script>alert('登录失败');</script>";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=login_doctor.php\" />";
    } else {
        echo "<script>alert('登录成功');</script>";
        $_SESSION['name'] = $name;
        $_SESSION['id'] = $id;
        $_SESSION['identity'] = "医生";
        echo " <meta http-equiv=\"refresh\" content=\"0; url=doctor.php\" />";
    }

    $conn->close();
}
else{}
?>
<!doctype html>
<html>
<head>
    <meta charset="gb2312">
    <title>医生登录</title>
    <link href="../css/style2.css" rel="stylesheet" type="text/css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="applicable-device" content="pc" />

    <link href="../css/bootstrap.css" rel="stylesheet" />
    <link href="../css/style.css" rel="stylesheet" />
</head>

<body>

    <header>

        <div class="topBox">
            <div class="borderBottom">
                <div class="container">
                    <div class="welcomeBox">欢迎光临xx医院网站</div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-6 col-md-8 logo"><a href=".../index.php"><img src="../images/logotem.png" width="364" height="84"/></a></div>
                    <div class="col-xs-6 col-sm-3 col-md-2">
                        <div class="tel">
                            <img src="../images/tel.gif" alt="" /><br />400-8888-8888
                        </div>
                    </div>
                    <?php
                    include("../online_user1.php");
                    ?>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-static-top navbar-default">
            <div class="111" style="margin-left: 50px">
                <div class="navbar-header">
                    <a class="navbar-brand" href="../index.php"></a>
                </div>
                <ul class="nav navbar-nav">
                    <li><a href="../index.php">网站首页</a></li>
                    <li><a href="../about.php">关于我们</a></li>
                    <li><a href="../article.php">新闻中心</a></li>
                    <li><a href="login_doctor.php">服务中心</a></li>
                    <li><a href=#>联系我们</a></li></ul></div>
   <center>
    <div class="background">
        <div class="div1">
            <h1 style="font-size: 18pt">医生登录账号</h1>
            <form method="post" action="<?php echo $PHP_SELF; ?>" >
                <table class="table1"  border="1" cellpadding="2" cellspacing="1" style="word-wrap:break-word;table-layout:fixed;">
                    <tr>
                        <td width="10px" align="center">id</td>
                        <td width="40px" >
                            <input  type="text" name="id" placeholder="请输入id号" required>
                        </td>
                    </tr>

                    <tr>
                        <td width="10px" align="center" >姓名</td>
                        <td width="40px" >
                            <input  type="text" name="name" placeholder="请输入姓名" required>
                        </td>
                    </tr>

                    <tr>
                        <td width="10px" align="center" nowrap>密码</td>
                        <td width="40px" nowrap>
                            <input  type="password" name="password" placeholder="请输入密码" required>
                        </td>
                    </tr>

                    <tr>
                        <td></td>
                        <td>

                            <!--                    <button>注册</button>-->
                            <input  type="submit" name="submit" value="登录" >
                        </td>
                    </tr>

                </table>
            </form>
        </div>
    </div>
</center>
<div style="background:#f9f9f9; padding-top:20px; margin-top:20px; padding-bottom:3px;"></div>
<footer>

    <div class="copyright">
        <p>
            <a href="../about.php">医院简介</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="../article.php">新闻中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href="login_doctor.php">服务中心</a>&nbsp;&nbsp;|&nbsp;&nbsp;
            <a href=#>联系我们</a>
        </p>
        <p class="copyright_p">制作人：刘万里 吴贤珠 唐伊凤</p>
    </div>

</footer>
</nav>
</body>
</html>